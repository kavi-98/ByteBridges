<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ByteBridges-bout Us</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap">
    <link rel="stylesheet" href="styles.css">
    <style>
        
    </style>
</head>
<body>

 <!-- Side Navigation -->
 <div class="side-nav" id="sideNav">
    <span class="close-btn" onclick="toggleSideNav()">&times;</span>
    <a href="home.php">Home</a>
    <a href="services.php">Services</a>
    <a href="about.php">About Us</a>
    <a href="blog.php">Blogs</a>
    <a href="contact.php">Contact Us</a>
</div>

<!-- Header Section -->
<header class="navbar">
        <div class="container">
            <div class="logo">
                <img src="img/icn/icon.png" alt="ByteBridges Logo">
                <h1>ByteBridges</h1>
            </div>
            <span class="menu-toggle" onclick="toggleSideNav()">&#9776;</span>
            <nav>
                <ul class="nav-links">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="services.php">Services</a></li>
                    <li><a href="about.php">About Us</a></li>
                    <li><a href="blog.php">Blogs</a></li>
                    <li><a href="contact.php">Contact us</a></li>
                </ul>
            </nav>
            
        </div>
    </header>

     <section class="xy">
        <div class="ab">
        <img src="img/s3.png" alt="Our Team" style="align:center;width: 600px; height: auto;"class="responsive" >
            <h1>
           About Byte Bridges </h1>
            <p>
                We’re fundamentally technology people. As part of EB Pearls, we’re laying the groundwork for web and mobile development innovations through laser-focused solutions.
            </p>
            <a href="contact.php" class="btn">Contact Us</a>
        </div>
    </section>


<section class="about-section">
     
        <div class="about-text">
            <h3 style="text-align: center; justify-content: center;font-size: 26px;">Our Mission</h3>
            <br>
            <p  style="justify-content: center;font-size: 16px;">
            Our mission is to provide reliable, scalable, and innovative IT solutions that help businesses adapt to the ever-changing technology landscape. We strive to foster long-term partnerships by delivering exceptional value through seamless digital transformation and exceptional customer service.</p>
        </div>
        <div class="about-text">
            <h3 style="text-align: center; justify-content: center;font-size: 26px;">Our Vision</h2>
            <br>
            <p  style="justify-content: center;font-size: 16px;">
            To be a global leader in delivering innovative and cutting-edge IT solutions that empower businesses to achieve their full potential and transform lives through technology. Highlights your ambition to lead in the global market."</p>
        </div>
    </section>




<section class="about-section">
<div class="about-image"style="align:rignt;">
            <img src="img/s5.png" alt="Our Team">
        </div>
        <div>
       <!--  <img src="img8.png" alt="Our Team" style="width: 400px; height: 300px;" > -->
    <h2>Who We Are</h2>
    <p>We are a leading IT company, providing cutting-edge solutions to clients worldwide. Our team of dedicated professionals is passionate about technology and innovation, delivering impactful results in the ever-evolving digital world.</p>
</div>
</section>



<section class="team-section">
    <h2>Byte Bridges offices</h2>
    <div class="team-cards">
        <div class="team-card">
            <img src="img/s11.png" alt="Team Member 1" style="align:center;width: 100px; height: auto;">
            <h3>London</h3>
            <p>Bankside 2 90-100 Southwark Street, London</p>
        </div>
        <div class="team-card">
            <img src="img/s12.png" alt="Team Member 2" style="align:center;width: 100px; height: auto;">
            <h3>Leeds</h3>
            <p>Platform, New Station Street Leeds</p>
        </div>
        <div class="team-card">
            <img src="img/s13.png" alt="Team Member 3" style="align:center;width: 100px; height: auto;">
            <h3>Manchester</h3>
            <p>111 Piccadilly, Manchester</p>
        </div>
    </div>
</section>

<footer>
        <div class="footer-content">
            <h4>ByteBridges</h4>
            <p>Your one-stop solution for IT services and technology needs.</p>

            <div class="social-links">
                <a href="#" target="_blank">Facebook</a>
                <a href="#" target="_blank">Twitter</a>
                <a href="#" target="_blank">LinkedIn</a>
                <a href="#" target="_blank">Instagram</a>
            </div>

            <div class="footer-bottom">
                <p>&copy; 2025 ByteBridges. All Rights Reserved. | <a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a></p>
            </div>
        </div>
    </footer>



<script>

function toggleSideNav() {
        const sideNav = document.getElementById('sideNav');
        sideNav.classList.toggle('open');
    }

    document.querySelectorAll('.nav-links > li').forEach(link => {
    link.addEventListener('click', () => {
        alert('Feature not yet implemented!');
    });
});
    </script>




</body>
</html>
