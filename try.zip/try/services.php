<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ByteBridges-Services</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap">
    <link rel="stylesheet" href="styles.css">
    <style>
        
    </style>
</head>
<body>
<!-- Header Section -->
<header class="navbar">
        <div class="container">
            <div class="logo">
                <img src="img/icn/icon.png" alt="ByteBridges Logo">
                <h1>ByteBridges</h1>
            </div>
            <span class="menu-toggle" onclick="toggleSideNav()">&#9776;</span>
            <nav>
                <ul class="nav-links">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="services.php">Services</a></li>
                    <li><a href="about.php">About Us</a></li>
                    <li><a href="blog.php">Blogs</a></li>
                    <li><a href="contact.php">Contact us</a></li>
                </ul>
            </nav>
            
        </div>
    </header>

 <!-- Side Navigation -->
 <div class="side-nav" id="sideNav">
    <span class="close-btn" onclick="toggleSideNav()">&times;</span>
    <a href="home.php">Home</a>
    <a href="services.php">Services</a>
    <a href="about.php">About Us</a>
    <a href="blog.php">Blogs</a>
    <a href="contact.php">Contact Us</a>
</div>

    <!-- Hero Section -->
    <section class="hero">
        <div class="container hero-content">
           
            <div class="image-content">
                <img src="img/service1.png" alt="service">
            </div>

            <div class="text-content">
                <h2 class="tagline">Small Business Website Design Services</h2>
                <h1>The World’s <span class="highlight">Best</span></h1>
                <p>Imagine, all the benefits of a large agency at a fraction of the cost. We’re not the cheapest option, but for the quality of what you get, there is no better value available.</p>
                <a href="services.php" class="btn">Learn more</a>
            </div>


        </div>
    </section>


<section class="about-section">
     
<div class="about-text">
            <h2 style="text-align: center; justify-content: center;">Custom Design</h2>
            <br>
            <p  style="justify-content: center;">All of our work is 100% custom. Designed for you in Figma. We never use pre-made templates. Ever.

We start with a Website Questionnaire, where we learn more about you, your company and customers. You will share other websites you like the look and feel of along with any fonts, colors or any other design directions you have.

We will then create a fully custom design, for free, based on your specifications.

Once we start working together you can take the design in any direction you would like. You will have plenty of rounds of revision to get the design exactly as you need.

</p>
        </div>
<div class="about-image"style="align:center;">
            <img src="img/s1.png" alt="Our Team"style=" width: 400px;  height: auto;align:center;">
        </div>
    </section>



<section class="services">
    <h2>What Services, We Give You!</h2>
    <br>
    <div class="service-cards">
        <div class="service-card">
            <img src="img/icn/SD.png" alt="Easy Booking">
            <h3>Software Development</h3>
            <p>Custom software solutions tailored to client needs.</p>
        </div>
        <div class="service-card">
            <img src="img/icn/CS.png" alt="Swimming Pool">
            <h3>Cloud Solutions</h3>
            <p>Cloud migration and integration.</p>
        </div>
        <div class="service-card">
            <img src="img/icn/IT C.png" alt="Mobile Payment">
            <h3>IT Consulting</h3>
            <p>IT strategy and planning.</p>
        </div>
        <div class="service-card">
            <img src="img/icn/M IT S.png" alt="Bank Card Services">
            <h3>Managed IT Services</h3>
            <p>Proactive network and system monitoring.</p>
        </div>
        <div class="service-card">
            <img src="img/icn/BI.png" alt="Best Home">
            <h3>Business Intelligence (BI) Solutions</h3>
            <p>Data analysis and reporting tools.</p>
        </div>
    </div>
        <br>
        <br>
    <div class="service-cards">
        <div class="service-card">
            <img src="img/icn/CL.png" alt="Swimming Pool">
            <h3>IT Infrastructure Management</h3>
            <p>Data center management and optimization.</p>
        </div>
        <div class="service-card">
            <img src="img/icn/AI.png" alt="Restaurant Home">
            <h3>Artificial Intelligence & Machine Learning</h3>
            <p>AI-driven automation and chatbots.
            </p>
        </div>
        <div class="service-card">
            <img src="img/icn/BC.png" alt="Mobile Payment">
            <h3>Business Continuity & Disaster Recovery</h3>
            <p>Data backup and recovery strategies.</p>
        </div>
        <div class="service-card">
            <img src="img/icn/EC.png" alt="Bank Card Services">
            <h3>E-Commerce Development</h3>
            <p>E-commerce website and platform development.</p>
        </div>
        <div class="service-card">
            <img src="img/icn/SEO.png" alt="Best Home">
            <h3>Digital Marketing & SEO</h3>
            <p>Website SEO optimization.</p>
        </div>
    </div>
</section>


<section class="about-section">
        <div class="about-text">
            <h2 style="text-align: center; justify-content: center;">Why Us?</h2>
            <br>
            <p  style="justify-content: center;">Our projects are priced on a flat fee basis. We hate it when projects go over budget as much as you do, that’s why over 95% of projects stay on budget.</p>
        </div>

        <div class="about-image"style="align:rignt;">
            <img src="img/s2.png" alt="Our Team">
        </div>
        
        <div class="about-text">
            <br>
            <br>
            <p  style="justify-content: center;">But don’t just take our word for it. Check out our 50+ Five Star reviews on places like Google Reviews and Yelp. We’ve been in business for over 10 years and have no negative reviews to show for it. The reason is, we really care about our clients and their experience with us.</p>
        </div>

    </section>

    <footer>
        <div class="footer-content">
            <h4>ByteBridges</h4>
            <p>Your one-stop solution for IT services and technology needs.</p>

            <div class="social-links">
                <a href="#" target="_blank">Facebook</a>
                <a href="#" target="_blank">Twitter</a>
                <a href="#" target="_blank">LinkedIn</a>
                <a href="#" target="_blank">Instagram</a>
            </div>

            <div class="footer-bottom">
                <p>&copy; 2025 ByteBridges. All Rights Reserved. | <a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a></p>
            </div>
        </div>
    </footer>


<script>

function toggleSideNav() {
        const sideNav = document.getElementById('sideNav');
        sideNav.classList.toggle('open');
    }

document.querySelectorAll('.nav-links > li').forEach(link => {
    link.addEventListener('click', () => {
        alert('Feature not yet implemented!');
    });
});

    //  mobile navigation
    function toggleNav() {
        const navLinks = document.querySelector('.nav-links');
        navLinks.style.display = navLinks.style.display === 'flex' ? 'none' : 'flex';
    }

    // Close nav 
    window.addEventListener('click', function(event) {
        const burgerMenu = document.querySelector('.burger-menu');
        const navLinks = document.querySelector('.nav-links');
        if (!burgerMenu.contains(event.target) && !navLinks.contains(event.target)) {
            navLinks.style.display = 'none';
        }
    });

     //  services 
     window.addEventListener('load', function() {
        const serviceCards = document.querySelectorAll('.service-card');

        
        serviceCards.forEach((card, index) => {
            setTimeout(() => {
                card.classList.add('visible');
            }, index * 200); 
        });
    });

    
</script>

</body>
</html>
