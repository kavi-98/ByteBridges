<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ByteBridges-Contact Us</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap">
    <link rel="stylesheet" href="styles.css">
    <style>

    </style>
</head>
<body>

<!-- Header Section -->
<header class="navbar">
        <div class="container">
            <div class="logo">
                <img src="img/icn/icon.png" alt="ByteBridges Logo">
                <h1>ByteBridges</h1>
            </div>
            <span class="menu-toggle" onclick="toggleSideNav()">&#9776;</span>
            <nav>
                <ul class="nav-links">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="services.php">Services</a></li>
                    <li><a href="about.php">About Us</a></li>
                    <li><a href="blog.php">Blogs</a></li>
                    <li><a href="contact.php">Contact us</a></li>
                </ul>
            </nav>
            
        </div>
    </header>


    
    <!-- Side Navigation -->
<div class="side-nav" id="sideNav">
    <span class="close-btn" onclick="toggleSideNav()">&times;</span>
    <a href="home.php">Home</a>
    <a href="services.php">Services</a>
    <a href="about.php">About Us</a>
    <a href="blog.php">Blogs</a>
    <a href="contact.php">Contact Us</a>
</div>


    <!-- Hero Section -->
    <section class="xy">
        <div class="ab">
        <img src="img/s7.png" alt="Our Team" style="align:center;width: 400px; height: auto;">
            <h1>
            Ready to achieve your vision? We're here to help. </h1>
            <p>
            We'd love to start a conversation. Fill out the form and we'll connect you with the right person.</p>
            <a href="contact.php" class="btn">Contact Us</a>
        </div>
    </section>

    <section class="about-section">
        <div class="about-text">
            <h2 style="text-align: center; justify-content: center;">Who We Are</h2>
            <br>
            <p  style="justify-content: center;">We are a leading IT company, providing cutting-edge solutions to clients worldwide. Our team of dedicated professionals is passionate about technology and innovation, delivering impactful results in the ever-evolving digital world.</p>
        </div>
        <div class="about-image"style="align:rignt;">
            <img src="img/img6.png" alt="Our Team">
        </div>
        <div class="about-text">
            <h2>Contact Us</h2>
            <br>
            <div class="icon-wrapper">
                <i class="fas fa-phone-alt"></i>
                <p><strong>Phone:</strong> +94 76 123-4567</p>
            </div>
            <br>
            <div class="icon-wrapper">
                <i class="fas fa-envelope"></i>
                <p><strong>Email:</strong> bytebridges@company.com</p>
            </div>
            <br>
            <div class="icon-wrapper">
                <i class="fas fa-map-marker-alt"></i>
                <p><strong>Address:</strong> Homagama, Sri Lanka.</p>
            </div>
         </div>
    </section>

<section class="contactus">
        <div class="contact-wrapper">
            <div class="contact-image">
                <img src="img/img7.png" alt="Paper plane illustration">
            </div>
            <div class="contact-card">
                <h1>Contact Us</h1>
                <p>
                    Or reach out manually to 
                    <a href="mailto:bytebridges@company.com">bytebridges@company.com</a>
                </p>
                <form id="contactForm">
                    <div class="input-group">
                        <label for="email">Email address</label>
                        <input type="email" id="email" name="email" placeholder="Enter your email" required>
                        <small>We'll never share your email with anyone else.</small>
                    </div>
                    <div class="input-group">
                        <label for="name">Your name</label>
                        <input type="text" id="name" name="name" placeholder="Enter your name" required>
                    </div>
                    <div class="input-group">
                        <label for="message">Your message</label>
                        <textarea id="message" name="message" placeholder="Enter your message" required></textarea>
                    </div>
                    <button type="submit">Send Message</button>
                </form>
            </div>
        </div>
    </section>


    <footer>
        <div class="footer-content">
            <h4>ByteBridges</h4>
            <p>Your one-stop solution for IT services and technology needs.</p>

            <div class="social-links">
                <a href="#" target="_blank">Facebook</a>
                <a href="#" target="_blank">Twitter</a>
                <a href="#" target="_blank">LinkedIn</a>
                <a href="#" target="_blank">Instagram</a>
            </div>

            <div class="footer-bottom">
                <p>&copy; 2025 ByteBridges. All Rights Reserved. | <a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a></p>
            </div>
        </div>
    </footer>


<script>

function toggleSideNav() {
        const sideNav = document.getElementById('sideNav');
        sideNav.classList.toggle('open');
    }

    document.querySelectorAll('.nav-links > li').forEach(link => {
        link.addEventListener('click', () => {
            alert('Feature not yet implemented!');
        });
    });


document.querySelectorAll('.nav-links > li').forEach(link => {
    link.addEventListener('click', () => {
        alert('Feature not yet implemented!');
    });
});

     document.getElementById("contactForm").addEventListener("submit", function (e) {
            e.preventDefault();

            const email = document.getElementById("email").value;
            const name = document.getElementById("name").value;
            const message = document.getElementById("message").value;

            alert(`Thank you, ${name}! Your message has been sent.`);
            document.getElementById("contactForm").reset();
        });

</script>

</body>
</html>
