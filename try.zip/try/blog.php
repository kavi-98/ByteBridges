<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ByteBridges-Blog</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap">
    <link rel="stylesheet" href="styles.css">
    <style>
        
    </style>
</head>
<body>

<!-- Header Section -->
<header class="navbar">
        <div class="container">
            <div class="logo">
                <img src="img/icn/icon.png" alt="ByteBridges Logo">
                <h1>ByteBridges</h1>
            </div>
            <span class="menu-toggle" onclick="toggleSideNav()">&#9776;</span>
            <nav>
                <ul class="nav-links">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="services.php">Services</a></li>
                    <li><a href="about.php">About Us</a></li>
                    <li><a href="blog.php">Blogs</a></li>
                    <li><a href="contact.php">Contact us</a></li>
                </ul>
            </nav>
            
        </div>
    </header>

 <!-- Side Navigation -->
 <div class="side-nav" id="sideNav">
    <span class="close-btn" onclick="toggleSideNav()">&times;</span>
    <a href="home.php">Home</a>
    <a href="services.php">Services</a>
    <a href="about.php">About Us</a>
    <a href="blog.php">Blogs</a>
    <a href="contact.php">Contact Us</a>
</div>

    <!-- Hero Section -->
    <section class="hero">
        <div class="container hero-content">
            <div class="text-content">
                <h2 class="tagline">Exploring Tomorrow, Today.</h2>
                <h1>Exclusive <span class="highlight">Website Tips</span></h1>
                <p>Stay ahead of the curve & get weekly updates on the latest industry trends, tips & news.</p>
                <a href="blog.php" class="btn">Learn more</a>
            </div>
            <div class="image-content">
                <img src="img/s6.png" alt="Student holding a book">
            </div>
        </div>
    </section>


<section class="xy">
        <div class="ab">
            <h1>
            We use Digital Product to Show our Appreciation of in the World </h1>
            <p>
                We’re fundamentally technology people. As part of EB Pearls, we’re laying the groundwork for web and mobile development innovations through laser-focused solutions.
            </p>
            <a href="contact.php" class="btn">Contact Us</a>
        </div>
    </section>



    <section class="blog" style="text-align: center;">
    
    <div class="image-container">
        <img src="img/s8.png" alt="Design and Code Tools Illustration">
    </div>
    
    <div class="content">
        <h2>How Emerging Technologies Are Transforming Businesses in 2025</h2>
        <p>
        Technology is evolving rapidly, and businesses must adapt to stay ahead of the competition. From AI-powered tools to blockchain innovations, here’s how emerging technologies are shaping the future.
        </p>
        <a href="" class="btn">See more</a>
</section>

<section class="blog" style="text-align: center;">
    <div class="content">
        <h2>5 Cybersecurity Mistakes Businesses Must Avoid</h2>
        <p>
        Cyberattacks are becoming more sophisticated, and businesses of all sizes are at risk. Protect your company by avoiding these common cybersecurity mistakes.
        </p>
        <a href="" class="btn">See more</a>
    </div>
    <div class="image-container">
        <img src="img/s9.png" alt="Design and Code Tools Illustration">
    </div>
</section>

<section class="blog" style="text-align: center;">
    
    <div class="image-container">
        <img src="img/s10.png" alt="Design and Code Tools Illustration">
    </div>
    
    <div class="content">
        <h2>The Benefits of Cloud Computing for Modern Businesses</h2>
        <p>
        Cloud computing has become the backbone of modern business operations. Here’s why companies are migrating to the cloud and how it can benefit your organization.
        </p>
        <a href="img/s10.png" class="btn">See more</a>
</section>

<footer>
        <div class="footer-content">
            <h4>ByteBridges</h4>
            <p>Your one-stop solution for IT services and technology needs.</p>

            <div class="social-links">
                <a href="#" target="_blank">Facebook</a>
                <a href="#" target="_blank">Twitter</a>
                <a href="#" target="_blank">LinkedIn</a>
                <a href="#" target="_blank">Instagram</a>
            </div>

            <div class="footer-bottom">
                <p>&copy; 2025 ByteBridges. All Rights Reserved. | <a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a></p>
            </div>
        </div>
    </footer>




<script>

function toggleSideNav() {
        const sideNav = document.getElementById('sideNav');
        sideNav.classList.toggle('open');
    }

    document.querySelectorAll('.nav-links > li').forEach(link => {
    link.addEventListener('click', () => {
        alert('Feature not yet implemented!');
    });
});
</script>

</body>
</html>
