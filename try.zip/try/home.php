<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ByteBridges</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap">
    <link rel="stylesheet" href="styles.css">
    <style>
        
    </style>
</head>
<body>

<!-- Header Section -->
<header class="navbar">
        <div class="container">
            <div class="logo">
                <img src="img/icn/icon.png" alt="ByteBridges Logo">
                <h1>ByteBridges</h1>
            </div>
            <span class="menu-toggle" onclick="toggleSideNav()">&#9776;</span>
            <nav>
                <ul class="nav-links">
                    <li><a href="#">Home</a></li>
                    <li><a href="services.php">Services</a></li>
                    <li><a href="about.php">About Us</a></li>
                    <li><a href="blog.php">Blogs</a></li>
                    <li><a href="contact.php">Contact us</a></li>
                </ul>
            </nav>
            
        </div>
    </header>
    
    <!-- Side Navigation -->
    <div class="side-nav" id="sideNav">
    <span class="close-btn" onclick="toggleSideNav()">&times;</span>
    <a href="home.php">Home</a>
    <a href="services.php">Services</a>
    <a href="about.php">About Us</a>
    <a href="blog.php">Blogs</a>
    <a href="contact.php">Contact Us</a>
</div>

    <!-- Hero Section -->
    <section class="hero">
        <div class="container hero-content">
            <div class="text-content">
                <h2 class="tagline">focus on high value tasks</h2>
                <h1>Unlock extraordinary <span class="highlight">opportunities.</span></h1>
                <p>we combine our global consulting expertise with a tailored delivery approach unique to each client’s needs. We believe client relationships built on authenticity and a shared vision can truly make a measurable impact.</p>
                <a href="about.php" class="btn">Learn more</a>
            </div>
            <div class="image-content">
                <img src="img/img2.png" alt="Student holding a book">
            </div>
        </div>
    </section>

<section class="xy">
        <div class="ab">
            <h1>
            We use Digital Product to Show our Appreciation of in the World            </h1>
            <p>
                We’re fundamentally technology people. As part of Byte Bridges, we’re laying the groundwork for web and mobile development innovations through laser-focused solutions.
            </p>
            <a href="contact.php" class="btn">Meet Our Team</a>
        </div>
    </section>

<section class="services">
    <h2>What Services, We Give You!</h2>
    <br>
    <div class="service-cards">
        <div class="service-card">
            <img src="img/icn/SD.png" alt="Easy Booking">
            <h3>Software Development</h3>
            <p>Custom software solutions tailored to client needs.</p>
        </div>
        <div class="service-card">
            <img src="img/icn/CS.png" alt="Swimming Pool">
            <h3>Cloud Solutions</h3>
            <p>Cloud migration and integration.</p>
        </div>
        <div class="service-card">
            <img src="img/icn/IT C.png" alt="Mobile Payment">
            <h3>IT Consulting</h3>
            <p>IT strategy and planning.</p>
        </div>
        <div class="service-card">
            <img src="img/icn/M IT S.png" alt="Bank Card Services">
            <h3>Managed IT Services</h3>
            <p>Proactive network and system monitoring.</p>
        </div>
        <div class="service-card">
            <img src="img/icn/BI.png" alt="Best Home">
            <h3>Business Intelligence (BI) Solutions</h3>
            <p>Data analysis and reporting tools.</p>
        </div>
    </div>
        <br>
        <br>
    <div class="service-cards">
        <div class="service-card">
            <img src="img/icn/CL.png" alt="Swimming Pool">
            <h3>IT Infrastructure Management</h3>
            <p>Data center management and optimization.</p>
        </div>
        <div class="service-card">
            <img src="img/icn/AI.png" alt="Restaurant Home">
            <h3>Artificial Intelligence & Machine Learning</h3>
            <p>AI-driven automation and chatbots.
            </p>
        </div>
        <div class="service-card">
            <img src="img/icn/BC.png" alt="Mobile Payment">
            <h3>Business Continuity & Disaster Recovery</h3>
            <p>Data backup and recovery strategies.</p>
        </div>
        <div class="service-card">
            <img src="img/icn/EC.png" alt="Bank Card Services">
            <h3>E-Commerce Development</h3>
            <p>E-commerce website and platform development.</p>
        </div>
        <div class="service-card">
            <img src="img/icn/SEO.png" alt="Best Home">
            <h3>Digital Marketing & SEO</h3>
            <p>Website SEO optimization.</p>
        </div>
    </div>
</section>


<section class="about-section">
        <div class="about-text">
            <h2 style="text-align: center; justify-content: center;">Who We Are</h2>
            <br>
            <p  style="justify-content: center;">We are a leading IT company, providing cutting-edge solutions to clients worldwide. Our team of dedicated professionals is passionate about technology and innovation, delivering impactful results in the ever-evolving digital world.</p>
        </div>
        <div class="about-image"style="align:rignt;">
            <img src="img/img6.png" alt="Our Team">
        </div>
        <div class="about-text">
            <h2>Contact Us</h2>
            <br>
            <div class="icon-wrapper">
                <i class="fas fa-phone-alt"></i>
                <p><strong>Phone:</strong> +94 76 123-4567</p>
            </div>
            <br>
            <div class="icon-wrapper">
                <i class="fas fa-envelope"></i>
                <p><strong>Email:</strong> bytebridges@company.com</p>
            </div>
            <br>
            <div class="icon-wrapper">
                <i class="fas fa-map-marker-alt"></i>
                <p><strong>Address:</strong> Homagama, Sri Lanka.</p>
            </div>
         </div>
    </section>



    <section class="contactus">
        <div class="contact-wrapper">
            <div class="contact-image">
                <img src="img/img7.png" alt="Paper plane illustration">
            </div>
            <div class="contact-card">
                <h1>Contact Us</h1>
                <p>
                    Or reach out manually to 
                    <a href="mailto:bytebridges@company.com">bytebridges@company.com</a>
                </p>
                <form id="contactForm">
                    <div class="input-group">
                        <label for="email">Email address</label>
                        <input type="email" id="email" name="email" placeholder="Enter your email" required>
                        <small>We'll never share your email with anyone else.</small>
                    </div>
                    <div class="input-group">
                        <label for="name">Your name</label>
                        <input type="text" id="name" name="name" placeholder="Enter your name" required>
                    </div>
                    <div class="input-group">
                        <label for="message">Your message</label>
                        <textarea id="message" name="message" placeholder="Enter your message" required></textarea>
                    </div>
                    <button type="submit">Send Message</button>
                </form>
            </div>
        </div>
    </section>


    <section class="feedback-section">
        <div class="feedback-header">
            <h2>Users Feedback</h2>
            <p>
                From online stores and agencies to content publishers, see what people across the web are saying.
            </p>
        </div>
        <div class="feedback-cards">
            <article class="feedback-card">
                <p>
                    After a nine-month period of optimizing our store with ReloadSEO, we have seen an increase of 60% in revenue from organic search rankings.
                </p>
                <h4>Kavindi Gamagedara</h4>
                <span>Owner and CEO</span>
            </article>
            <article class="feedback-card">
                <p>
                    After a nine-month period of optimizing from organic search rankings, we saw an increase of 60% in revenue for our store with ReloadSEO.
                </p>
                <h4>Louis Sunera</h4>
                <span>Founder and CEO</span>
            </article>
            <article class="feedback-card">
                <p>
                    After a nine-month period of optimizing our store with ReloadSEO, we have seen a 60% increase in revenue from organic search rankings.
                </p>
                <h4>Samantha Ekanayake</h4>
                <span>Owner and CEO</span>
            </article>
        </div>
    </section>



<footer>
        <div class="footer-content">
            <h4>ByteBridges</h4>
            <p>Your one-stop solution for IT services and technology needs.</p>

            <div class="social-links">
                <a href="#" target="_blank">Facebook</a>
                <a href="#" target="_blank">Twitter</a>
                <a href="#" target="_blank">LinkedIn</a>
                <a href="#" target="_blank">Instagram</a>
            </div>

            <div class="footer-bottom">
                <p>&copy; 2025 ByteBridges. All Rights Reserved. | <a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a></p>
            </div>
        </div>
    </footer>


<script>

function toggleSideNav() {
        const sideNav = document.getElementById('sideNav');
        sideNav.classList.toggle('open');
    }

document.querySelectorAll('.nav-links > li').forEach(link => {
    link.addEventListener('click', () => {
        alert('Feature not yet implemented!');
    });
});

    //  Navbar Dropdown 
document.querySelectorAll('.nav-links > li').forEach(link => {
    link.addEventListener('click', () => {
        alert('Feature not yet implemented!');
    });
});
    // Close nav 
    window.addEventListener('click', function(event) {
        const burgerMenu = document.querySelector('.burger-menu');
        const navLinks = document.querySelector('.nav-links');
        if (!burgerMenu.contains(event.target) && !navLinks.contains(event.target)) {
            navLinks.style.display = 'none';
        }
    });

     //  services 
     window.addEventListener('load', function() {
        const serviceCards = document.querySelectorAll('.service-card');

        // 
        serviceCards.forEach((card, index) => {
            setTimeout(() => {
                card.classList.add('visible');
            }, index * 200); 
        });
    });

    document.getElementById("contactForm").addEventListener("submit", function (e) {
            e.preventDefault();

            const email = document.getElementById("email").value;
            const name = document.getElementById("name").value;
            const message = document.getElementById("message").value;

            alert(`Thank you, ${name}! Your message has been sent.`);
            document.getElementById("contactForm").reset();
        });

</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/js/all.min.js"></script>
<script>
     form submission
    document.getElementById('contact-form').addEventListener('submit', function(event) {
        event.preventDefault();
        
       
        alert('Thank you for contacting us! We will get back to you soon.');
    });
</script>

</body>
</html>
